SafeChadGPT Setup (Render.com)

1. Go to https://render.com and create an account.
2. Click "New" > "Web Service". Choose "Manual Deploy".
3. Upload this ZIP when asked.
4. Set your Start Command to: python main.py
5. Add Environment Variable:
   - Key: BOT_TOKEN
   - Value: your Telegram bot token (from @BotFather)
6. Deploy and get your Render URL (e.g., https://safechadgpt.onrender.com)
7. Set your Telegram webhook by opening this in your browser:

https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook?url=https://safechadgpt.onrender.com
